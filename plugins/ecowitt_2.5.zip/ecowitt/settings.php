<?php
 // ecowitt setup file


$forward_server = 'realrunning.netsons.org/template/api.php';
$forward_server_password = 'fanofano';
$txt_data_log = true;
$ws80_temperature_correction = false;
?>
